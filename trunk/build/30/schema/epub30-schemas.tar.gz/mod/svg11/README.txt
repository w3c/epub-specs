$Id: README.txt 3024 2011-07-10 08:29:17Z eb2mmrt $
$Author: eb2mmrt $

This directory contains a RELAX NG schema, namely svg11-flat.rnc, for
SVG 1.1 (2nd Edition).  It is automatically created by trang from
svg11-flat.dtd, available at
http://www.w3.org/Graphics/SVG/1.1/DTD/svg11-flat.dtd (08-July-2011).

See W3C_Software_License.txt about the W3C SOFTWARE NOTICE AND LICENSE.

